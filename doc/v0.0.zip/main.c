//
//  main.c
//  LaunchpadSeq
//
//  Created by Guillaume Gekière on 01/10/2023.
//

#include <CoreMIDI/MIDIServices.h>
#include <CoreFoundation/CFRunLoop.h>

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "launchpad_defs.h"

/*
*       Step: A representation of a value at a given time
*       Pattern: Group of pre-defined number of steps
*/

typedef enum Mode {
	kMode_Edit = 0,
	kMode_Mute = 1,
}Mode;

typedef enum SequencerState {
	kSequencerState_Stopped,
	kSequencerState_Playing,
	kSequencerState_Paused
}SequencerState;

typedef enum Direction {
	kDirection_Forward = 1,
	kDirection_Backward = -1
}Direction;

typedef enum SLMIDIMessageType {
	kSLMIDIMessageType_NoteOff						    = 0x80,
	kSLMIDIMessageType_NoteOn						    = 0x90,
	kSLMIDIMessageType_AftertouchPoly					= 0xA0,
	kSLMIDIMessageType_ControlChange				    = 0xB0,
	kSLMIDIMessageType_ProgramChange				    = 0xC0,
	kSLMIDIMessageType_AftertouchChannel		    	= 0xD0,
	kSLMIDIMessageType_PitchWheel					    = 0xE0,
	kSLMIDIMessageType_System						    = 0xF0,
	kSLMIDIMessageType_SystemClockTick				    = 0xFA,
	kSLMIDIMessageType_SystemClockStart				    = 0xFB,
	kSLMIDIMessageType_SystemClockContinue		    	= 0xFC,
	kSLMIDIMessageType_SystemClockStop				    = 0xFD,
	kSLMIDIMessageType_SystemClockActiveSensing			= 0xFE,
	kSLMIDIMessageType_SystemClockReset			    	= 0xFF
} SLMIDIMessageType;

#define IS_HIGH(value)              value > 0
#define DEBUG						1

#define N_TRIGGERS                  8
#define MAX_STEPS                   64
#define DEFAULT_STEPS               8

#define HOLD_NOTES                  0

#define DEFAUTL_MIDI_IN_CHANNEL     1
#define DEFAUTL_MIDI_OUT_CHANNEL    2

#define CLOCK_IN_PIN                2
#define CLOCK_OUT_PIN               3
#define RESET_PIN                   4

#define N_LEDS                      16              // Number of LEDs in the strip
#define LED_DATA_PIN                6               // Pin connected to the data input of the LED strip


// PINS DEFINITIONS
const uint8_t               t_outputs[N_TRIGGERS] = {
	30,31,32,33,
	34,35,36,37,
	38,39,40,41,
	42,43,44,45
};
// MAPPERS
const uint8_t               b_midi_mapping[N_TRIGGERS] = {
	60,61,62,63,
	64,65,66,67,
	68,69,70,71,
	72,73,74,75
};  //used for midi notes
const uint8_t               b_value_mapping[N_TRIGGERS] = {
	255,255,255,255,
	255,255,255,255,
	255,255,255,255,
	255,255,255,255
};  //might be for velocity or other analog purposes

MIDIPortRef     			gOutPort = NULL;
MIDIEndpointRef 			gDest = NULL;

// STATE
uint8_t                     patterns[N_TRIGGERS][MAX_STEPS] = {0};          // N_TRIGGERS triggers with MAX_STEPS steps
bool                        muted_triggers[N_TRIGGERS] = {0};
uint8_t                     current_pattern_index = 0;
Mode                        current_mode = kMode_Edit;
bool						current_outs[N_TRIGGERS] = {0};

uint8_t                     state_indexes[N_TRIGGERS] = {0};
uint8_t                     last_state_indexes[N_TRIGGERS] = {0};
volatile uint8_t            clock_cpt = 0;
volatile uint8_t            clock_divider = 0;                              //ROM
uint8_t 					ls_page_index = 0;
bool						shift_btn_hold = false;
bool						clear_btn_hold = false;

// MIDI
uint8_t                     midi_mapping_offset = 0;                        //ROM
uint8_t                     midi_out_channel = DEFAUTL_MIDI_OUT_CHANNEL;     //ROM
uint8_t                     midi_in_channel = DEFAUTL_MIDI_IN_CHANNEL;     //ROM

// - Sequence related
SequencerState              current_seq_state = kSequencerState_Stopped;
Direction		            current_seq_dir = kDirection_Forward;
volatile uint8_t            current_step_indexes[N_TRIGGERS] = {0};
uint8_t                     last_step_indexes[N_TRIGGERS] = {DEFAULT_STEPS};


void updateDisplay(void);
void clearPattern(uint8_t patternIndex);
void clearAllPattern(void);
void stopSequencer(void);
void playSequencer(void);
void pauseSequencer(void);

void ls_updateCell(uint8_t x, uint8_t y);				//sends 1 MIDI messages
void ls_updateRow(uint8_t rowIndex);					//sends 8 MIDI messages
void ls_updateGrid(void);								//sends 64 MIDI messages
void ls_updateFnButtons(void);							//sends 16 MIDI messages
bool ls_btnIsDown(MIDIPacket *packet);
void ls_updateOutColumn(void);
void ls_setFunctionButton(uint16_t btnIndex, uint8_t color);

static void midi_send(MIDIPacket *pkt, uint8_t channel);

// --- SETs  ---

void setCurrentPatternIndex(uint8_t index) {
	if (current_pattern_index != index) {
		current_pattern_index = index;
	}
}

void resetCurrentStepIndexes(void) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		current_step_indexes[i] = 0;
	}
	
	ls_updateGrid();
}

void incrCurrentStepIndexes(int value) {
	// value can be positive or negative
	uint8_t prev[N_TRIGGERS] = {0};
	
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		//circular loop (0 to n)
		prev[i] = current_step_indexes[i];
		current_step_indexes[i] = (current_step_indexes[i] + value + last_step_indexes[i]) % last_step_indexes[i];
		//update only previous col and current col to avoid a complete grid update (reduces midi traffic)
		ls_updateCell(current_step_indexes[i] % LS_MAX_STEPS_PER_ROW, i);
		ls_updateCell(prev[i] % LS_MAX_STEPS_PER_ROW, i);
		
		//assign current outs
		current_outs[i] = !muted_triggers[i] ? patterns[i][current_step_indexes[i]] : 0;
		ls_updateOutColumn();
	}
}

void setPatternStepValue(uint8_t patternIndex, uint8_t stepIndex, uint8_t value) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		patterns[patternIndex][stepIndex] = value;

		//LS Update if in range
		ls_updateCell(stepIndex % LS_MAX_STEPS_PER_ROW, patternIndex);
	}
}

void togglePatternStepValue(uint8_t patternIndex, uint8_t stepIndex) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		uint8_t curVal = patterns[patternIndex][stepIndex];
		if (curVal) {
			setPatternStepValue(patternIndex, stepIndex, 0);
		} else {
			setPatternStepValue(patternIndex, stepIndex, 255);
		}
	}
}

// --- LS ---

void ls_incrPageIndex(int8_t value) {
	const uint8_t max = (uint8_t)(MAX_STEPS / LS_MAX_STEPS_PER_ROW);
	const uint8_t newValue = (ls_page_index + value + max) % max;
	if (newValue != ls_page_index) {
		ls_page_index = newValue;
	}
	
	updateDisplay();
}

void ls_setFunctionButton(uint16_t btnIndex, uint8_t color) {
	MIDIPacket pkt = {0};
	pkt.length = 3;
	pkt.timeStamp = 0;
	pkt.data[0] = btnIndex >> 8;
	pkt.data[1] = btnIndex & 0x00ff;
	pkt.data[2] = color;
	midi_send(&pkt, 0);
}

uint16_t ls_btnMapValue(MIDIPacket *packet) {
	return LS_BT_CONVERT(packet->data[0], packet->data[1]);
}

bool ls_btnIsDown(MIDIPacket *packet) {
	return packet->data[2] > 0;
}

void ls_updateRow(uint8_t rowIndex) {
	if (rowIndex > LS_ROWS) {
		return;
	}
	
	for(size_t x = 0; x < LS_COLS; x++) {
		ls_updateCell(x, rowIndex);
	}
}

void editOutSub(void) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		uint16_t baseValue = LS_BT_VOL | ((i << 4) & 0xf0);
		uint8_t color = LS_COLOR_NONE;
		
		if (current_outs[i]) {
			color = LS_COLOR_AMBER;
		}
		
		ls_setFunctionButton(baseValue, color);
	}
}

void muteOutSub(void) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		uint16_t baseValue = LS_BT_VOL | ((i << 4) & 0xf0);
		uint8_t color = 0x1C;
		if (!muted_triggers[i]) {
			color = LS_COLOR_GREEN;
		}
		ls_setFunctionButton(baseValue, color);
	}
}

void ls_updateOutColumn(void) {
	switch(current_mode) {
		case kMode_Edit:
			editOutSub();
			break;
		case kMode_Mute:
			muteOutSub();
			break;
	}
}

//TODO
void ls_updateFnButtons(void) {
	switch (current_mode) {
		case kMode_Edit:
			ls_setFunctionButton(LS_BT_MUTE, LS_COLOR_AMBER);
			break;
		case kMode_Mute:
			ls_setFunctionButton(LS_BT_MUTE, LS_COLOR_GREEN);
			break;
		default:
			break;
	}
	if (ls_page_index == 0) {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color none
	} else {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color green
	}
}

void ls_updateCell(uint8_t x, uint8_t y) {
	if (x > LS_COLS) {
		return;
	}
	if (y > LS_ROWS) {
		return;
	}
	
	uint8_t patternIndex = y;
	uint8_t stepIndex = x + (ls_page_index * LS_MAX_STEPS_PER_ROW);
	uint8_t color = LS_COLOR_NONE;
	uint8_t value = patterns[patternIndex][stepIndex];
	bool channelMuted = muted_triggers[patternIndex];
	Mode currentMode = current_mode;
	const uint8_t bckColor = current_mode == kMode_Edit ? 0x0D : LS_COLOR_NONE;
	
	//let's check if we are in range first
	if (stepIndex >= (ls_page_index * LS_MAX_STEPS_PER_ROW) && stepIndex < LS_MAX_STEPS_PER_ROW + (ls_page_index * LS_MAX_STEPS_PER_ROW)) {
		
		//are we in range of last step ?
		if (stepIndex < last_step_indexes[patternIndex]) {
			if (current_seq_state == kSequencerState_Playing && stepIndex == current_step_indexes[patternIndex]) {
				// seq line index --> yellow
				color = 0x1D;
				
				if (IS_HIGH(value)) {
					color =  !channelMuted ? LS_COLOR_AMBER : 0x1D;
				}
			} else {
				
				if (IS_HIGH(value)) {
					//light up high red for used slots
					color = !channelMuted ? LS_COLOR_GREEN : 0x1C;
				} else {
					//light up low red for unused slots
					color = bckColor;
				}
			}
		}
		
		MIDIPacket pkt = {0};
		pkt.length = 3;
		pkt.timeStamp = CFAbsoluteTimeGetCurrent();
		pkt.data[0] = kSLMIDIMessageType_NoteOn;
		pkt.data[1] = LS_PKT_TO_GRID_POS(x % LS_MAX_STEPS_PER_ROW, y);
		pkt.data[2] = color;
		
		midi_send(&pkt, 0);
	}
	
}

void ls_updateGrid() {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		for (size_t j = 0; j < LS_MAX_STEPS_PER_ROW; j++) {
			ls_updateCell(j, i);
		}
	}
}


// --- UPDATES ---

void updateDisplay(void) {
	switch (current_mode) {
		case kMode_Edit:
			break;
		case kMode_Mute:
			break;
		default:
			break;
	}
	
	ls_updateGrid();
	ls_updateFnButtons();
	ls_updateOutColumn();
}

// --- PATTERN ---

void clearPattern(uint8_t patternIndex) {
	if (patternIndex < N_TRIGGERS) {
		//bzero(&patterns[patternIndex], MAX_STEPS);
		memset(patterns[patternIndex], 0, MAX_STEPS);
//		patterns[patternIndex] = {0};
		ls_updateRow(patternIndex);
	}
	
}

void clearAllPatterns(void) {
	for (int i = 0; i < N_TRIGGERS; i++) {
		clearPattern(i);
	}
	ls_updateGrid();
}

// --- OUTPUTS ---

void endTriggerOutput(size_t outputIndex) {
//	if (outputIndex < N_B_COLS * N_B_ROWS) {
//		digitalWrite(t_outputs[outputIndex], LOW);
//		MIDI.sendNoteOff(b_midi_mapping[outputIndex] + midi_mapping_offset, 0, midi_out_channel);
//	}
}

void triggerOutput(size_t outputIndex, uint8_t value) {
	if (outputIndex < N_TRIGGERS) {
#if HOLD_NOTES
		// Analog out
		// Update value no matter if it changed or not
		digitalWrite(t_outputs[outputIndex], value > 0 ? HIGH : LOW);
		// MIDI
		
		// Send a MIDI event only if the state has changed since
		if (state_indexes[outputIndex] != last_state_indexes[outputIndex]) {
			// We need to see if which event to send
			if (state_indexes[outputIndex] && !last_state_indexes[outputIndex]) {
				//noteOn (0 to 1)

			} else if (!state_indexes[outputIndex] && last_state_indexes[outputIndex]) {
				//noteOff (1 to 0)
			}
		}
#else
		if (!muted_triggers[outputIndex]) {
			// TODO: what if we need dotted notes for each step ?
//			digitalWrite(t_outputs[outputIndex], value > 0 ? HIGH : LOW);
//			MIDI.sendNoteOn(b_midi_mapping[outputIndex] + midi_mapping_offset, b_value_mapping[outputIndex], midi_out_channel);
		}
#endif
		
	}
}

// --- SEQ ---

void stopSequencer(void) {
	// Reset all step indexes to 0
	memset(current_step_indexes, 0, sizeof(current_step_indexes));
	current_seq_state = kSequencerState_Stopped;
	updateDisplay();
}

void playSequencer(void) {
	current_seq_state = kSequencerState_Playing;
	updateDisplay();
}

void pauseSequencer(void) {
	current_seq_state = kSequencerState_Paused;
	updateDisplay();
}

// --- Interrupts ---

void clockInterruptCallback() {
	/*
	* When there is no clock in trigger no sequenced output will be triggered !
	*/

	clock_cpt++;

	if (clock_divider > 0) {
		// Block further instructions
		if (clock_cpt % clock_divider != 0) {
			return;
		}
	}
	
	const Direction dir = current_seq_dir;
//	const Direction dir = digitalRead(DIR_PIN) ? kDirection_Backward : kDirection_Forward;
	if (clock_cpt > MAX_STEPS) {
		//TODO: determine highest last step or use defined current max steps (ARTURIA way)
		
	}
	
	incrCurrentStepIndexes(dir == kDirection_Forward ? 1 : -1);

	// reset all outputs to 0
	//TODO: might find a better way with millis
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		endTriggerOutput(i);
	}

	// trigger every ON outputs selected by the current step
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		triggerOutput(i, patterns[i][current_step_indexes[i]]);
	}
}

void resetInterruptCallback() {
	clock_cpt = 0;
	stopSequencer();
	playSequencer();
}

// --- MAIN ---

void setup() {
	// Setup interrupts
	//attachInterrupt(digitalPinToInterrupt(CLOCK_IN_PIN), clockInterruptCallback, RISING);
	//attachInterrupt(digitalPinToInterrupt(RESET_PIN), resetInterruptCallback, RISING);

	// Setup MIDI
	
	memset(last_step_indexes, DEFAULT_STEPS, sizeof(last_step_indexes));
	current_seq_state = kSequencerState_Playing;
	
	muted_triggers[3] = true;
	
	incrCurrentStepIndexes(0);
	
	patterns[0][0] = 255;
	patterns[0][4] = 255;
	patterns[0][8] = 255;
	patterns[0][12] = 255;
	
	patterns[1][4] = 255;
	patterns[1][12] = 255;
	
	patterns[2][2] = 255;
	patterns[2][6] = 255;
	patterns[2][10] = 255;
	patterns[2][14] = 255;
	
	patterns[3][0] = 255;
	patterns[3][2] = 255;
	patterns[3][4] = 255;
	patterns[3][6] = 255;
	patterns[3][8] = 255;
	patterns[3][10] = 255;
	patterns[3][12] = 255;

	updateDisplay();
}

void loop() {
		
//	updateLeds(); // Update LEDs
//	updateDisplay(); // Update Display
	
	//--- UX LOGIC ---

	switch (current_mode) {
		case kMode_Edit:
			for (size_t i = 0; i < N_TRIGGERS; i++) {
				// assign the pressed buttons to the current pattern
				if (state_indexes[i] > 0) {
					patterns[current_pattern_index][i] = state_indexes[i];
				}
			}
			
			break;
		
		default:
			break;
	}

	//--- OUTPUT PART ---

	switch (current_mode) {
		
		default:
			break;
	}
}

static void midi_send(MIDIPacket *pkt, uint8_t channel) {
	if (gOutPort != NULL && gDest != NULL) {
		// Initialize a MIDIPacketList
		MIDITimeStamp timestamp = 0; // 0 will mean play now.
		uint8_t buffer[1024]; // storage space for MIDI Packets (max 65536)

		//MIDIPacketList packetList;
		MIDIPacketList *packetlist = (MIDIPacketList*)buffer;
		MIDIPacket *packet = MIDIPacketListInit(packetlist);
		
		// Create a MIDIPacket within the packetList
		packet = MIDIPacketListAdd(packetlist, sizeof(buffer), packet, timestamp, 3, pkt->data);
#if DEBUG
//		printf("SENDING: len: %d \t%02X %02X %02X\n",
//			   packet->length,
//			   packet->data[0],
//			   packet->data[1],
//			   packet->data[2]);
#endif
		// Check if the packet was added successfully
		if (packet != NULL) {
			// Send the packet list using MIDISend
			MIDISend(gOutPort, gDest, packetlist);
		} else {
			// Handle the case where the packet could not be added
			// (e.g., packet buffer is too small)
		}
	}
}
#define LS_BT_VOL							0x9008
#define LS_BT_PAN							0x9018

bool processColButton(MIDIPacket *packet) {
	//uint16_t baseValue = LS_BT_VOL;
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		/*
		 BT VALUE Example:
		 0x9008
		 0x9018
		 0x9028
		 */
		uint16_t v = 0x90 << 8 | i << 4 | 0x08;
		if (ls_btnMapValue(packet) == v && ls_btnIsDown(packet)) {
			if (clear_btn_hold) {
				clearPattern(i);
			}
			if (current_mode == kMode_Mute) {
				
				muted_triggers[i] = !muted_triggers[i];
				ls_updateRow(i);
				
				ls_updateFnButtons();
				ls_updateOutColumn();
			}
			
			return true;
		}
	}
	
	return false;
}


static void midi_read_callback(const MIDIPacketList *evtList, void *refCon, void *connRefCon)
{
	if (gOutPort != NULL && gDest != NULL) {
		MIDIPacket *packet = (MIDIPacket *)evtList->packet;
		
		for (size_t j = 0; j < evtList->numPackets; ++j) {
			// go through each pkt bytes
//			for (size_t i = 0; i < packet->length; ++i) {
//
//				// rechannelize status bytes
//				if (packet->data[i] >= kSLMIDIMessageType_NoteOff && packet->data[i] < kSLMIDIMessageType_System) {
//					//packet->data[i] = (packet->data[i] & kSLMIDIMessageType_System) | midi_in_channel;
//				}
//			}
			
			//process packet here
			bool isFunctionButton = true;
			
			if (packet->length >= 3) {
				if (ls_btnMapValue(packet) == LS_BT_SHIFT) {
					shift_btn_hold = ls_btnIsDown(packet);
					ls_setFunctionButton(LS_BT_SHIFT, ls_btnIsDown(packet) ? LS_COLOR_YELLOW : LS_COLOR_NONE);
				} if (ls_btnMapValue(packet) == LS_BT_CLEAR) {
					clear_btn_hold = ls_btnIsDown(packet);
					ls_setFunctionButton(LS_BT_CLEAR, ls_btnIsDown(packet) ? LS_COLOR_RED : LS_COLOR_NONE);
					
					if (shift_btn_hold && clear_btn_hold) {
						clearAllPatterns();
					}
				}  else if (ls_btnMapValue(packet) == LS_BT_UP_ARROW && ls_btnIsDown(packet)) {
#if DEBUG
					current_seq_dir = kDirection_Forward;
					clockInterruptCallback();
#endif
				} else if (ls_btnMapValue(packet) == LS_BT_DOWN_ARROW && ls_btnIsDown(packet)) {
#if DEBUG
					current_seq_dir = kDirection_Backward;
					clockInterruptCallback();
#endif
				} else if (ls_btnMapValue(packet) == LS_BT_LEFT_ARROW && ls_btnIsDown(packet)) {
					ls_incrPageIndex(-1);
				} else if (ls_btnMapValue(packet) == LS_BT_RIGHT_ARROW && ls_btnIsDown(packet)) {
					ls_incrPageIndex(1);
				} else if (ls_btnMapValue(packet) == LS_BT_RESET && ls_btnIsDown(packet)) {
#if DEBUG
					resetCurrentStepIndexes();
#endif
				} else if (ls_btnMapValue(packet) == LS_BT_MUTE && ls_btnIsDown(packet)) {
					current_mode = !current_mode;
//					ls_updateFnButtons();
//					ls_updateOutColumn();
					updateDisplay();
				}
				//--------
				else if (!processColButton(packet)) {
					isFunctionButton = false;
					SLMIDIMessageType   type = packet->data[0] & 0xF0;
					uint8_t             incommingChannel = packet->data[0] & 0x0F;
					
					if (ls_btnIsDown(packet)) {
						switch(type) {
						  case kSLMIDIMessageType_NoteOn:
							{
								uint8_t x = packet->data[1] % 16;
								uint8_t y = (packet->data[1] - x) / 16;
								
								if (!shift_btn_hold) {
									//toggle one step
									togglePatternStepValue(y, x + (ls_page_index * LS_MAX_STEPS_PER_ROW));
								} else {
									//determines the last step
									//TODO: method
									last_step_indexes[y] = x + (ls_page_index * LS_MAX_STEPS_PER_ROW) + 1;
									ls_updateRow(y);
								}
							}
							break;
						  case kSLMIDIMessageType_NoteOff:
							//handleNoteOff(incommingChannel, packet->data[1] & 0xEF, packet->data[2] & 0xEF);
							break;
						  default:
							break;
						}
					}
					
				}
#if DEBUG
				if (ls_btnIsDown(packet)) {
					printf("-----------------\n");
					printf("SHIFT: %d\n", shift_btn_hold);
					printf("PAGE IDX: %d\n", ls_page_index);
					printf("RECV: len: %d \t%02X %02X %02X\n",
						   packet->length,
						   packet->data[0],
						   packet->data[1],
						   packet->data[2]);
				}
#endif
			}
		
			//packet->data[2] = LS_COLOR_YELLOW - 0x08;
			
			packet = MIDIPacketNext(packet);
		}
		
		
		
		//loopback pkt
		//if (isFunctionButton) {
			//MIDISend(gOutPort, gDest, evtList);
		//}
	}
}

int main(int argc, const char * argv[]) {
	// create client and ports
	MIDIClientRef client = NULL;
	MIDIClientCreate(CFSTR("MIDI Echo"), NULL, NULL, &client);

	MIDIPortRef inPort = NULL;
	MIDIInputPortCreate(client, CFSTR("Input port"), midi_read_callback, NULL, &inPort);
	MIDIOutputPortCreate(client, CFSTR("Output port"), &gOutPort);

	// enumerate devices (not really related to purpose of the echo program
	// but shows how to get information about devices)
	int i, n;
	CFStringRef pname, pmanuf, pmodel;
	char name[64], manuf[64], model[64];

	n = (int)MIDIGetNumberOfDevices();
	for (i = 0; i < n; ++i) {
		MIDIDeviceRef dev = MIDIGetDevice(i);

		MIDIObjectGetStringProperty(dev, kMIDIPropertyName, &pname);
		MIDIObjectGetStringProperty(dev, kMIDIPropertyManufacturer, &pmanuf);
		MIDIObjectGetStringProperty(dev, kMIDIPropertyModel, &pmodel);

		CFStringGetCString(pname, name, sizeof(name), 0);
		CFStringGetCString(pmanuf, manuf, sizeof(manuf), 0);
		CFStringGetCString(pmodel, model, sizeof(model), 0);
		CFRelease(pname);
		CFRelease(pmanuf);
		CFRelease(pmodel);

		printf("name=%s, manuf=%s, model=%s\n", name, manuf, model);
	}

	// open connections from all sources
	n = (int)MIDIGetNumberOfSources();
	printf("%d sources\n", n);
	for (i = 0; i < n; ++i) {
		MIDIEndpointRef src = MIDIGetSource(i);
		MIDIPortConnectSource(inPort, src, NULL);
	}

	// find the first destination
	n = (int)MIDIGetNumberOfDestinations();
	if (n > 0)
		gDest = MIDIGetDestination(0);

	if (gDest != NULL) {
		MIDIObjectGetStringProperty(gDest, kMIDIPropertyName, &pname);
		CFStringGetCString(pname, name, sizeof(name), 0);
		CFRelease(pname);
		printf("Echoing to channel %d of %s\n", midi_out_channel, name);
	} else {
		printf("No MIDI destinations present\n");
	}
	
	setup();
	
	// Create a dispatch queue (you can use the main queue or create a custom one)
	dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
	// Create a dispatch source timer
	dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
	
	if (timer) {
		// Set the time interval for the timer (in nanoseconds)
		uint64_t interval = NSEC_PER_SEC * 0.125; // 1 second
		dispatch_source_set_timer(timer, dispatch_time(DISPATCH_TIME_NOW, 0), interval, 0);
		
		// Define the event handler block for the timer
		dispatch_source_set_event_handler(timer, ^{
			clockInterruptCallback();
		});
		
		// Start the timer
		dispatch_resume(timer);
	}
	

	CFRunLoopRun();
	
	return 0;
}
