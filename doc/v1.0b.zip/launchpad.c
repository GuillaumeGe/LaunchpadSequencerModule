//
//  launchpad.c
//  LaunchpadSeq
//
//  Created by Guillaume Gekière on 18/10/2023.
//

#include <stdio.h>
#include "launchpad.h"


void ls_init(launchpad_t * l, step_sequencer_t * seq) {
	l->page_index = 0;
	l->shift_btn_hold = false;
	l->clear_btn_hold = false;
	l->sequencer = seq;
	if (seq != NULL) {
		l->selected_sequence_index = l->sequencer->current_sequence_index;
	}
}

void ls_midi_send(launchpad_t * l, SLMIDIPacket * pkt, uint8_t channel) {
	if (l->midi_snd_cb != NULL) {
		l->midi_snd_cb(pkt, channel);
	}
}

void ls_incrPageIndex(launchpad_t * l, int8_t value) {
	const uint8_t max = (uint8_t)(MAX_STEPS / LS_MAX_STEPS_PER_ROW);
	const uint8_t newValue = (l->page_index + value + max) % max;
	if (newValue != l->page_index) {
		l->page_index = newValue;
	}
	
	ls_updateDisplay(l);
}

void ls_setFunctionButton(launchpad_t * l, uint16_t btnIndex, uint8_t color) {
	SLMIDIPacket pkt = {0};
	pkt.length = 3;
	pkt.data[0] = btnIndex >> 8;
	pkt.data[1] = btnIndex & 0x00ff;
	pkt.data[2] = color;
	ls_midi_send(l, &pkt, 0);
}

uint16_t ls_btnMapValue(SLMIDIPacket *packet) {
	return LS_BT_CONVERT(packet->data[0], packet->data[1]);
}

bool ls_btnIsDown(SLMIDIPacket * packet) {
	return packet->data[2] > 0;
}

void ls_updateRow(launchpad_t * l, uint8_t rowIndex) {
	if (rowIndex > LS_ROWS) {
		return;
	}
	
	for(size_t x = 0; x < LS_COLS; x++) {
		ls_updateCell(l, x, rowIndex);
	}
}

void ls_editOutSub(launchpad_t * l) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		uint16_t baseValue = LS_BT_VOL | ((i << 4) & 0xf0);
		uint8_t color = LS_COLOR_NONE;
		
		if (l->sequencer->current_outs[i]) {
			color = LS_COLOR_AMBER;
		}
		
		ls_setFunctionButton(l, baseValue, color);
	}
}

void ls_muteOutSub(launchpad_t * l) {
	step_sequence_t * cs = &l->sequencer->sequences[l->selected_sequence_index];
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		uint16_t baseValue = LS_BT_VOL | ((i << 4) & 0xf0);
		uint8_t color = 0x1C;
		if (!cs->muted_triggers[i]) {
			color = LS_COLOR_GREEN;
		}
		ls_setFunctionButton(l, baseValue, color);
	}
}

void ls_updateOutColumn(launchpad_t * l) {
	switch(l->selected_mode) {
		case kMode_Pattern:
			ls_editOutSub(l);
			break;
		case kMode_Mute:
			ls_muteOutSub(l);
			break;
		case kMode_Sequence:
			break;
		case kMode_Settings:
			break;
	}
}

//TODO
void ls_updateFnButtons(launchpad_t * l) {
	switch (l->selected_mode) {
		case kMode_Pattern:
			ls_setFunctionButton(l, LS_BT_MUTE, LS_COLOR_AMBER);
			break;
		case kMode_Mute:
			ls_setFunctionButton(l, LS_BT_MUTE, LS_COLOR_GREEN);
			break;
		default:
			break;
	}
	if (l->page_index == 0) {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color none
	} else {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color green
	}
}

//TODO: update with mode
void ls_updateCell(launchpad_t * l, uint8_t x, uint8_t y) {
	if (x > LS_COLS) {
		return;
	}
	if (y > LS_ROWS) {
		return;
	}
	
	if (l->sequencer == NULL) {
		return;
	}
	
	uint8_t color = LS_COLOR_NONE;
	const step_sequence_t * cs = &l->sequencer->sequences[l->selected_sequence_index];
	const uint8_t patternIndex = y;
	const uint8_t stepIndex = x + (l->page_index * LS_MAX_STEPS_PER_ROW);
	const  uint8_t value = cs->patterns[patternIndex][stepIndex];
	const bool channelMuted = cs->muted_triggers[patternIndex];
	const ViewMode currentMode = l->selected_mode;
	const uint8_t bckColor = l->selected_mode == kMode_Pattern ? 0x0D : LS_COLOR_NONE;
	
	//let's check if we are in range first
	if (stepIndex >= (l->page_index * LS_MAX_STEPS_PER_ROW) && stepIndex < LS_MAX_STEPS_PER_ROW + (l->page_index * LS_MAX_STEPS_PER_ROW)) {
		
		//are we in range of last step ?
		if (stepIndex < cs->last_step_indexes[patternIndex]) {
			if (l->sequencer->current_state == kSequencerState_Playing && stepIndex == cs->current_step_indexes[patternIndex]) {
				// seq line index --> yellow
				color = 0x1D;
				
				if (IS_HIGH(value)) {
					color =  !channelMuted ? LS_COLOR_AMBER : 0x1D;
				}
			} else {
				if (IS_HIGH(value)) {
					//light up high red for used slots
					color = !channelMuted ? LS_COLOR_GREEN : 0x1C;
				} else {
					//light up low red for unused slots
					color = bckColor;
				}
			}
		}
		
		SLMIDIPacket pkt = {0};
		pkt.length = 3;
		pkt.data[0] = kSLMIDIMessageType_NoteOn;
		pkt.data[1] = LS_PKT_TO_GRID_POS(x % LS_MAX_STEPS_PER_ROW, y);
		pkt.data[2] = color;
		
		ls_midi_send(l, &pkt, 0);
	}
}

void ls_updateGrid(launchpad_t * l) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		for (size_t j = 0; j < LS_MAX_STEPS_PER_ROW; j++) {
			ls_updateCell(l, j, i);
		}
	}
}


// --- UPDATES ---

void ls_updateDisplay(launchpad_t * l) {
	switch (l->selected_mode) {
		case kMode_Pattern:
			break;
		case kMode_Mute:
			break;
		default:
			break;
	}
	
	ls_updateGrid(l);
	ls_updateFnButtons(l);
	ls_updateOutColumn(l);
}
