//
//  sequencer.h
//  LaunchpadSeq
//
//  Created by Guillaume Gekiere on 18/10/2023.
//

#ifndef sequencer_h
#define sequencer_h

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#define N_SEQUENCES                 8
#define N_TRIGGERS                  8
#define MAX_STEPS                   64
#define DEFAULT_STEPS               8

typedef enum SequencerState {
	kSequencerState_Stopped,
	kSequencerState_Playing,
	kSequencerState_Paused
}SequencerState;

typedef enum Direction {
	kDirection_Forward = 1,
	kDirection_Backward = -1
}Direction;

typedef struct step_sequence_t step_sequence_t;
typedef struct step_sequencer_t step_sequencer_t;

typedef struct step_sequence_t {
	uint8_t                     patterns[N_TRIGGERS][MAX_STEPS] ;          // N_TRIGGERS triggers with MAX_STEPS steps
	bool                        muted_triggers[N_TRIGGERS];
	uint8_t                     current_pattern_index;
	volatile uint8_t            current_step_indexes[N_TRIGGERS];
	uint8_t                     last_step_indexes[N_TRIGGERS];
	step_sequencer_t *			sequencer_ref;
	bool						empty;
	
	void 						(*step_updated_cb)(void * seq, uint8_t patternIndex, uint8_t stepIndex);
	void 						(*pattern_updated_cb)(void * seq, uint8_t patternIndex);
} step_sequence_t;

void seq_init(step_sequence_t * s);
void seq_stop(step_sequence_t * s);
void seq_play(step_sequence_t * s);
void seq_pause(step_sequence_t * s);
void seq_clearPattern(step_sequence_t * s, uint8_t patternIndex);
void seq_clearAllPatterns(step_sequence_t * s);
void seq_resetCurrentStepIndexes(step_sequence_t * s);
void seq_setPatternStepValue(step_sequence_t * s, uint8_t patternIndex, uint8_t stepIndex, uint8_t value);
void seq_togglePatternStepValue(step_sequence_t * s, uint8_t patternIndex, uint8_t stepIndex);

/*
*       Step: A representation of a value at a given time
*       Pattern: Group of pre-defined number of steps
*/

typedef struct step_sequencer_t {
	step_sequence_t				sequences[N_SEQUENCES];
	volatile uint8_t            clock_cpt;
	volatile uint8_t            clock_divider;                              //ROMs
	SequencerState              current_state;
	Direction		            current_direction;
	bool						current_outs[N_TRIGGERS];
	uint8_t						current_sequence_index;

	void 						(*step_updated_cb)(void * seq, uint8_t sequence_index, uint8_t patternIndex, uint8_t stepIndex);
	void 						(*pattern_updated_cb)(void * seq, uint8_t sequence_index, uint8_t patternIndex);
	void 						(*outputs_updated_cb)(void * seq);
	void 						(*direction_updated_cb)(void * seq);
	void 						(*state_updated_cb)(void * seq);

} step_sequencer_t;



void sequencer_init(step_sequencer_t * s);
//void sequencer_clearPattern(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex);
//void sequencer_clearAllPatterns(step_sequencer_t * s, uint8_t sequence_index);
void sequencer_clearAll(step_sequencer_t * s);
void sequencer_clock(step_sequencer_t * s);
void sequencer_stop(step_sequencer_t * s);
void sequencer_play(step_sequencer_t * s);
void sequencer_pause(step_sequencer_t * s);

void sequencer_resetCurrentStepIndexes(step_sequencer_t * s, uint8_t sequence_index);
//void sequencer_setPatternStepValue(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex, uint8_t stepIndex, uint8_t value);
//void sequencer_togglePatternStepValue(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex, uint8_t stepIndex);

#endif /* sequencer_h */
