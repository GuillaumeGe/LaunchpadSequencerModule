//
//  sequencer.c
//  LaunchpadSeq
//
//  Created by Guillaume Gekiere on 18/10/2023.
//

#include "sequencer.h"
#include <stdio.h>
#include <string.h>


void seq_init(step_sequence_t * s) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		memset((void *) s->patterns[i], 0, MAX_STEPS);
	}
	
	memset((void *) s->current_step_indexes, 0, sizeof(s->current_step_indexes));
	memset((void *) s->last_step_indexes, DEFAULT_STEPS, sizeof(s->last_step_indexes));
	
	s->current_pattern_index = 0;
	s->empty = true;
}

void seq_stop(step_sequence_t * s) {
	// Reset all step indexes to 0
	memset((void *) s->current_step_indexes, 0, sizeof(s->current_step_indexes));
}

void seq_play(step_sequence_t * s) {
	
}

void seq_pause(step_sequence_t * s) {
	
}

void seq_clearPattern(step_sequence_t * s, uint8_t patternIndex) {
	if (patternIndex < N_TRIGGERS) {
		memset((void *) s->patterns[patternIndex], 0, MAX_STEPS);
		if (s->pattern_updated_cb != NULL) {
			s->pattern_updated_cb(s, patternIndex);
		}
	}
}

void seq_clearAllPatterns(step_sequence_t * s) {
	s->empty = true;
	for (int i = 0; i < N_TRIGGERS; i++) {
		seq_clearPattern(s, i);
	}
}

void seq_setCurrentPatternIndex(step_sequence_t * s, uint8_t index) {
	if (s->current_pattern_index != index) {
		s->current_pattern_index = index;
	}
}

void seq_resetCurrentStepIndexes(step_sequence_t * s) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		s->current_step_indexes[i] = 0;
	}
}

void seq_setPatternStepValue(step_sequence_t * s, uint8_t patternIndex, uint8_t stepIndex, uint8_t value) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		s->patterns[patternIndex][stepIndex] = value;
		if (s->step_updated_cb != NULL) {
			s->step_updated_cb(s, patternIndex, stepIndex);
		}
	}
}

void seq_togglePatternStepValue(step_sequence_t * s, uint8_t patternIndex, uint8_t stepIndex) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		uint8_t curVal = s->patterns[patternIndex][stepIndex];
		if (curVal) {
			seq_setPatternStepValue(s, patternIndex, stepIndex, 0);
		} else {
			seq_setPatternStepValue(s, patternIndex, stepIndex, 255);
		}
	}
}

void seq_incrCurrentStepIndexes(step_sequence_t * s, int value) {
	uint8_t prev[N_TRIGGERS] = {0};
	
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		prev[i] = s->current_step_indexes[i];
		s->current_step_indexes[i] = (s->current_step_indexes[i] + value + s->last_step_indexes[i]) % s->last_step_indexes[i]; //circular loop (0 to n)
		// Update only previous col and current col to avoid a complete grid update (reduces midi traffic)
		if (s->step_updated_cb != NULL) {
			s->step_updated_cb(s, i, s->current_step_indexes[i]);
			s->step_updated_cb(s, i, prev[i]);
		}
	}
}


//-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------

void _sequencer_sequence_step_update_callback(void * sequence, uint8_t patternIndex, uint8_t stepIndex) {
	step_sequence_t * sq = (step_sequence_t *)sequence;
	
	if (sq != NULL && sq->sequencer_ref != NULL) {
		if (sq->sequencer_ref->step_updated_cb != NULL) {
			//TODO: handle seq index
			sq->sequencer_ref->step_updated_cb(sq->sequencer_ref, 0, patternIndex, stepIndex);
		}
	}
}

void _sequencer_sequence_pattern_update_callback(void * sequence, uint8_t patternIndex) {
	step_sequence_t * sq = (step_sequence_t *)sequence;
	
	if (sq != NULL && sq->sequencer_ref != NULL) {
		if (sq->sequencer_ref->pattern_updated_cb != NULL) {
			//TODO: handle seq index
			sq->sequencer_ref->pattern_updated_cb(sq->sequencer_ref, 0, patternIndex);
		}
	}
}


void sequencer_init(step_sequencer_t * s) {
	s->current_sequence_index = 0;
	s->clock_cpt = 0;
	s->clock_divider = 4;
	s->current_state = kSequencerState_Stopped;
	s->current_direction = kDirection_Forward;
	
	memset((void *) s->current_outs, 0, sizeof(s->current_outs));
	
	for (size_t i = 0; i < N_SEQUENCES; i++) {
		seq_init(&s->sequences[i]);
		s->sequences[i].sequencer_ref = s;
		s->sequences[i].step_updated_cb = _sequencer_sequence_step_update_callback;
		s->sequences[i].pattern_updated_cb = _sequencer_sequence_pattern_update_callback;
	}

	//TODO: load preset for seq 0
	
	//incrCurrentStepIndexes(0);
	
	/*
	s->patterns[0][0] = 255;
	s->patterns[0][4] = 255;
	s->patterns[0][8] = 255;
	s->patterns[0][12] = 255;
	
	s->patterns[1][4] = 255;
	s->patterns[1][12] = 255;
	
	s->patterns[2][2] = 255;
	s->patterns[2][6] = 255;
	s->patterns[2][10] = 255;
	s->patterns[2][14] = 255;
	
	s->patterns[3][0] = 255;
	s->patterns[3][2] = 255;
	s->patterns[3][4] = 255;
	s->patterns[3][6] = 255;
	s->patterns[3][8] = 255;
	s->patterns[3][10] = 255;
	s->patterns[3][12] = 255;
	 */
}

void sequencer_incrCurrentStepIndexes(step_sequencer_t * sequencer, int value) {
	step_sequence_t * seq = &sequencer->sequences[sequencer->current_sequence_index];

	seq_incrCurrentStepIndexes(seq, value); 	// value can be positive or negative
	
	//TODO: movevaroutside of seq + cb call
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		//assign current outs
		sequencer->current_outs[i] = !seq->muted_triggers[i] ? seq->patterns[i][seq->current_step_indexes[i]] : 0;
	}
	
	if (sequencer->outputs_updated_cb != NULL) {
		sequencer->outputs_updated_cb(sequencer);
	}
}

void sequencer_clock(step_sequencer_t * s) {
	s->clock_cpt++;

	if (s->clock_divider > 0) {
		// Block further instructions
		if (s->clock_cpt % s->clock_divider != 0) {
			return;
		}
	}
	
	const Direction dir = s->current_direction;
//	const Direction dir = digitalRead(DIR_PIN) ? kDirection_Backward : kDirection_Forward;
	if (s->clock_cpt > MAX_STEPS) {
		//TODO: determine highest last step or use defined current max steps (ARTURIA way)
		
	}
	
	sequencer_incrCurrentStepIndexes(s, dir == kDirection_Forward ? 1 : -1);
}

void sequencer_stop(step_sequencer_t * s) {
	seq_stop(&s->sequences[s->current_sequence_index]);
	
	s->current_state = kSequencerState_Stopped;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sequencer_play(step_sequencer_t * s) {
	seq_play(&s->sequences[s->current_sequence_index]);

	s->current_state = kSequencerState_Playing;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sequencer_pause(step_sequencer_t * s) {
	seq_pause(&s->sequences[s->current_sequence_index]);

	s->current_state = kSequencerState_Paused;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sequencer_clearPattern(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex) {
	if (sequence_index >= N_SEQUENCES) {
		return;
	}
	
	seq_clearPattern(&s->sequences[sequence_index], patternIndex);
}

void sequencer_clearAllPatterns(step_sequencer_t * s, uint8_t sequence_index) {
	if (sequence_index >= N_SEQUENCES) {
		return;
	}
	
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		sequencer_clearPattern(s, sequence_index, i);
	}
	//TODO: update grid ?
}

//void sequencer_setCurrentPatternIndex(step_sequencer_t * s, uint8_t sequence_index, uint8_t pattern_index) {
//	if (s->current_pattern_index != index) {
//		s->current_pattern_index = index;
//	}
//
//}

void sequencer_resetCurrentStepIndexes(step_sequencer_t * s, uint8_t sequence_index) {
	if (sequence_index < N_SEQUENCES) {
		seq_resetCurrentStepIndexes(&s->sequences[sequence_index]);
		
		//TODO: add specific cb
		if (s->state_updated_cb != NULL) {
			s->state_updated_cb(s);
		}
	}
}

void sequencer_setPatternStepValue(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex, uint8_t stepIndex, uint8_t value) {
	if (sequence_index < N_SEQUENCES) {
		seq_setPatternStepValue(&s->sequences[sequence_index], patternIndex, stepIndex, value);
		if (s->step_updated_cb != NULL) {
			s->step_updated_cb(s, sequence_index, patternIndex, stepIndex);
		}
	}
}

void sequencer_togglePatternStepValue(step_sequencer_t * s, uint8_t sequence_index, uint8_t patternIndex, uint8_t stepIndex) {
	if (sequence_index < N_SEQUENCES) {
		seq_togglePatternStepValue(&s->sequences[sequence_index], patternIndex, stepIndex);
	}
}
