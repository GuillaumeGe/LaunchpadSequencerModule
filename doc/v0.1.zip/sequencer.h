//
//  sequencer.h
//  LaunchpadSeq
//
//  Created by Guillaume Gekiere on 18/10/2023.
//

#ifndef sequencer_h
#define sequencer_h

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#define N_TRIGGERS                  8
#define MAX_STEPS                   64
#define DEFAULT_STEPS               8

typedef enum SequencerState {
	kSequencerState_Stopped,
	kSequencerState_Playing,
	kSequencerState_Paused
}SequencerState;

typedef enum Direction {
	kDirection_Forward = 1,
	kDirection_Backward = -1
}Direction;

/*
*       Step: A representation of a value at a given time
*       Pattern: Group of pre-defined number of steps
*/

typedef struct step_sequencer_t {
	uint8_t                     patterns[N_TRIGGERS][MAX_STEPS] ;          // N_TRIGGERS triggers with MAX_STEPS steps
	bool                        muted_triggers[N_TRIGGERS];
	uint8_t                     current_pattern_index;
	bool						current_outs[N_TRIGGERS];
	volatile uint8_t            clock_cpt;
	volatile uint8_t            clock_divider;                              //ROMs
	SequencerState              current_seq_state;
	Direction		            current_seq_dir;
	volatile uint8_t            current_step_indexes[N_TRIGGERS];
	uint8_t                     last_step_indexes[N_TRIGGERS];
	
	void 						(*step_updated_cb)(void * seq, uint8_t patternIndex, uint8_t stepIndex);
	void 						(*pattern_updated_cb)(void * seq, uint8_t patternIndex);
	void 						(*outputs_updated_cb)(void * seq);
	void 						(*direction_updated_cb)(void * seq);
	void 						(*state_updated_cb)(void * seq);

} step_sequencer_t;


void sq_init(step_sequencer_t * s);
void sq_clearPattern(step_sequencer_t * s, uint8_t patternIndex);
void sq_clearAllPatterns(step_sequencer_t * s);
void sq_clock(step_sequencer_t * s);
void sq_stop(step_sequencer_t * s);
void sq_play(step_sequencer_t * s);
void sq_pause(step_sequencer_t * s);

void sq_resetCurrentStepIndexes(step_sequencer_t * s);
void sq_setPatternStepValue(step_sequencer_t * s, uint8_t patternIndex, uint8_t stepIndex, uint8_t value);
void sq_togglePatternStepValue(step_sequencer_t * s, uint8_t patternIndex, uint8_t stepIndex);

#endif /* sequencer_h */
