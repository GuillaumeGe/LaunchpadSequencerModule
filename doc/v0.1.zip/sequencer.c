//
//  sequencer.c
//  LaunchpadSeq
//
//  Created by Guillaume Gekiere on 18/10/2023.
//

#include "sequencer.h"
#include <stdio.h>
#include <string.h>

void sq_init(step_sequencer_t * s) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		memset((void *) s->patterns[i], 0, MAX_STEPS);
	}
	memset((void *) s->current_outs, 0, sizeof(s->current_outs));
	memset((void *) s->current_step_indexes, 0, sizeof(s->current_step_indexes));
	memset((void *) s->last_step_indexes, DEFAULT_STEPS, sizeof(s->last_step_indexes));
	
	s->current_pattern_index = 0;
	s->clock_cpt = 0;
	s->clock_divider = 4;
	s->current_seq_state = kSequencerState_Stopped;
	s->current_seq_dir = kDirection_Forward;
	
	//incrCurrentStepIndexes(0);
	
	/*
	s->patterns[0][0] = 255;
	s->patterns[0][4] = 255;
	s->patterns[0][8] = 255;
	s->patterns[0][12] = 255;
	
	s->patterns[1][4] = 255;
	s->patterns[1][12] = 255;
	
	s->patterns[2][2] = 255;
	s->patterns[2][6] = 255;
	s->patterns[2][10] = 255;
	s->patterns[2][14] = 255;
	
	s->patterns[3][0] = 255;
	s->patterns[3][2] = 255;
	s->patterns[3][4] = 255;
	s->patterns[3][6] = 255;
	s->patterns[3][8] = 255;
	s->patterns[3][10] = 255;
	s->patterns[3][12] = 255;
	 */
}

void sq_incrCurrentStepIndexes(step_sequencer_t * s, int value) {
	// value can be positive or negative
	uint8_t prev[N_TRIGGERS] = {0};
	
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		prev[i] = s->current_step_indexes[i];
		s->current_step_indexes[i] = (s->current_step_indexes[i] + value + s->last_step_indexes[i]) % s->last_step_indexes[i]; //circular loop (0 to n)
		// Update only previous col and current col to avoid a complete grid update (reduces midi traffic)
		if (s->step_updated_cb != NULL) {
			s->step_updated_cb(s, i, s->current_step_indexes[i]);
			s->step_updated_cb(s, i, prev[i]);
		}
		
		//assign current outs
		//TODO: movevaroutside of seq + cb call
		s->current_outs[i] = !s->muted_triggers[i] ? s->patterns[i][s->current_step_indexes[i]] : 0;
	}
	
	if (s->outputs_updated_cb != NULL) {
		s->outputs_updated_cb(s);
	}
}

void sq_clock(step_sequencer_t * s) {
	s->clock_cpt++;

	if (s->clock_divider > 0) {
		// Block further instructions
		if (s->clock_cpt % s->clock_divider != 0) {
			return;
		}
	}
	
	const Direction dir = s->current_seq_dir;
//	const Direction dir = digitalRead(DIR_PIN) ? kDirection_Backward : kDirection_Forward;
	if (s->clock_cpt > MAX_STEPS) {
		//TODO: determine highest last step or use defined current max steps (ARTURIA way)
		
	}
	
	sq_incrCurrentStepIndexes(s, dir == kDirection_Forward ? 1 : -1);
}

void sq_stop(step_sequencer_t * s) {
	// Reset all step indexes to 0
	memset((void *) s->current_step_indexes, 0, sizeof(s->current_step_indexes));
	s->current_seq_state = kSequencerState_Stopped;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sq_play(step_sequencer_t * s) {
	s->current_seq_state = kSequencerState_Playing;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sq_pause(step_sequencer_t * s) {
	s->current_seq_state = kSequencerState_Paused;
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sq_clearPattern(step_sequencer_t * s, uint8_t patternIndex) {
	if (patternIndex < N_TRIGGERS) {
		memset((void *) s->patterns[patternIndex], 0, MAX_STEPS);
		if (s->pattern_updated_cb != NULL) {
			s->pattern_updated_cb(s, patternIndex);
		}
	}
}

void sq_clearAllPatterns(step_sequencer_t * s) {
	for (int i = 0; i < N_TRIGGERS; i++) {
		sq_clearPattern(s, i);
		if (s->pattern_updated_cb != NULL) {
			s->pattern_updated_cb(s, i);
		}
	}
	//TODO: update grid ?
}

void sq_setCurrentPatternIndex(step_sequencer_t * s, uint8_t index) {
	if (s->current_pattern_index != index) {
		s->current_pattern_index = index;
	}
}

void sq_resetCurrentStepIndexes(step_sequencer_t * s) {
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		s->current_step_indexes[i] = 0;
	}
	
	//TODO: add specific cb
	if (s->state_updated_cb != NULL) {
		s->state_updated_cb(s);
	}
}

void sq_setPatternStepValue(step_sequencer_t * s, uint8_t patternIndex, uint8_t stepIndex, uint8_t value) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		s->patterns[patternIndex][stepIndex] = value;
		if (s->step_updated_cb != NULL) {
			s->step_updated_cb(s, patternIndex, stepIndex);
		}
	}
}

void sq_togglePatternStepValue(step_sequencer_t * s, uint8_t patternIndex, uint8_t stepIndex) {
	if (patternIndex < N_TRIGGERS && stepIndex < MAX_STEPS) {
		uint8_t curVal = s->patterns[patternIndex][stepIndex];
		if (curVal) {
			sq_setPatternStepValue(s, patternIndex, stepIndex, 0);
		} else {
			sq_setPatternStepValue(s, patternIndex, stepIndex, 255);
		}
	}
}
