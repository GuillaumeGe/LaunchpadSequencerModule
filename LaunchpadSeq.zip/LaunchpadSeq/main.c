//
//  main.c
//  LaunchpadSeq
//
//  Created by Guillaume Gekière on 01/10/2023.
//

#include <CoreMIDI/MIDIServices.h>
#include <CoreFoundation/CFRunLoop.h>

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "launchpad_defs.h"

/*
*       Step: A representation of a value at a given time
*       Pattern: Group of pre-defined number of steps
*       Sequence: Group of patterns
*       Song: Group of sequences
*/

typedef enum Mode {
	kMode_Edit = 0,
	kMode_Instr = 1,
}Mode;

typedef enum SequencerState {
	kSequencerState_Stopped,
	kSequencerState_Playing,
	kSequencerState_Paused
}SequencerState;

typedef enum Direction {
	kDirection_Forward = 1,
	kDirection_Backward = -1
}Direction;

typedef enum SLMIDIMessageType {
	kSLMIDIMessageType_NoteOff						    = 0x80,
	kSLMIDIMessageType_NoteOn						    = 0x90,
	kSLMIDIMessageType_AftertouchPoly					= 0xA0,
	kSLMIDIMessageType_ControlChange				    = 0xB0,
	kSLMIDIMessageType_ProgramChange				    = 0xC0,
	kSLMIDIMessageType_AftertouchChannel		    	= 0xD0,
	kSLMIDIMessageType_PitchWheel					    = 0xE0,
	kSLMIDIMessageType_System						    = 0xF0,
	kSLMIDIMessageType_SystemClockTick				    = 0xFA,
	kSLMIDIMessageType_SystemClockStart				    = 0xFB,
	kSLMIDIMessageType_SystemClockContinue		    	= 0xFC,
	kSLMIDIMessageType_SystemClockStop				    = 0xFD,
	kSLMIDIMessageType_SystemClockActiveSensing			= 0xFE,
	kSLMIDIMessageType_SystemClockReset			    	= 0xFF
} SLMIDIMessageType;

#define IS_HIGH(value)              value > 0
#define DEBUG						1

#define N_B_COLS                    4
#define N_B_ROWS                    4
#define N_TRIGGERS                  N_B_COLS * N_B_ROWS
#define MAX_STEPS                   64
#define MAX_STEPS_ROW               16

#define HOLD_NOTES                  0

#define DEFAUTL_MIDI_IN_CHANNEL     1
#define DEFAUTL_MIDI_OUT_CHANNEL    2

#define CLOCK_IN_PIN                2
#define CLOCK_OUT_PIN               3
#define RESET_PIN                   4

#define N_LEDS                      16              // Number of LEDs in the strip
#define LED_DATA_PIN                6               // Pin connected to the data input of the LED strip


// PINS DEFINITIONS
const uint8_t               b_rows[N_B_ROWS] = {22,24,26,28};
const uint8_t               b_cols[N_B_COLS] = {23,25,27,29};
const uint8_t               t_outputs[N_TRIGGERS] = {
	30,31,32,33,
	34,35,36,37,
	38,39,40,41,
	42,43,44,45
};
// MAPPERS
const uint8_t               b_midi_mapping[N_TRIGGERS] = {
	60,61,62,63,
	64,65,66,67,
	68,69,70,71,
	72,73,74,75
};  //used for midi notes
const uint8_t               b_value_mapping[N_TRIGGERS] = {
	255,255,255,255,
	255,255,255,255,
	255,255,255,255,
	255,255,255,255
};  //might be for velocity or other analog purposes

MIDIPortRef     			gOutPort = NULL;
MIDIEndpointRef 			gDest = NULL;

// STATE
uint8_t                     patterns[N_TRIGGERS][MAX_STEPS] = {0};          // N_TRIGGERS triggers with MAX_STEPS steps
bool                        muted_triggers[N_TRIGGERS] = {0};
uint8_t                     current_pattern_index = 0;
Mode                        current_mode = kMode_Instr;
uint8_t                     state_indexes[N_TRIGGERS] = {0};
uint8_t                     last_state_indexes[N_TRIGGERS] = {0};
volatile uint8_t            clock_cpt = 0;
volatile uint8_t            clock_divider = 0;                              //ROM
uint8_t 					ls_page_index = 0;
bool						shift_btn_hold = false;

// MIDI
uint8_t                     midi_mapping_offset = 0;                        //ROM
uint8_t                     midi_out_channel = DEFAUTL_MIDI_OUT_CHANNEL;     //ROM
uint8_t                     midi_in_channel = DEFAUTL_MIDI_IN_CHANNEL;     //ROM

// - Sequence related
SequencerState              current_seq_state = kSequencerState_Stopped;
Direction		            current_seq_dir = kDirection_Forward;
volatile uint8_t            current_step_indexes[N_TRIGGERS] = {0};
uint8_t                     last_step_indexes[N_TRIGGERS] = {MAX_STEPS_ROW};


void updateDisplay(void);
void clearPattern(uint8_t patternIndex);
void clearAllPattern(void);
void stopSequencer(void);
void playSequencer(void);
void pauseSequencer(void);

// --- SETs  ---

void setCurrentPatternIndex(uint8_t index) {
	if (current_pattern_index != index) {
		current_pattern_index = index;
	}
}

void incrCurrentStepIndexes(int value) {
	// value can be positive or negative
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		//circular loop (0 to n)
		current_step_indexes[i] = (current_step_indexes[i] + value + last_step_indexes[i]) % last_step_indexes[i];
	}
}

// --- LS ---

void ls_setPageIndex(uint8_t index) {
	ls_page_index = index;
	updateDisplay();
	//can go up ?
	//can go down ?
	if (ls_page_index == 0) {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color none
	} else {
		//LS_BT_RIGHT_ARROW --> color green
		//LS_BT_LEFT_ARROW --> color green
	}
}

uint16_t ls_btnMapValue(MIDIPacket *packet) {
	return LS_PKT_TO_BT(packet->data[0], packet->data[1]);
}

bool ls_btnIsDown(MIDIPacket *packet) {
	return packet->data[2] > 0;
}


void ls_updateCell(uint8_t x_value, uint8_t y_value, uint8_t color) {
//  midi1.sendNoteOn(x_value + (y_value * 16), color, 1);
}

void ls_rapidUpdate(uint8_t ** grid) {
	//noteOn channel 3 msg
	
}

void ls_updateGrid(bool useRapidUpdate) {
	uint8_t ls_grid[LS_ROWS + 2][LS_COLS] = {0};
	uint8_t ls_bt_mode_index = LS_ROWS;
	uint8_t ls_bt_clip_index = LS_ROWS + 1;
	
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		for (size_t j = 0; j < last_step_indexes[i]; j++) {
			uint8_t val = patterns[i][j];
			uint8_t color = LS_COLOR_NONE;
			
			if (current_seq_state == kSequencerState_Playing && j == current_step_indexes[i]) {
				// seq line index --> yellow
				color = LS_COLOR_YELLOW;
			} else {
				if (IS_HIGH(val)) {
					//light up high red for used slots
					color = LS_COLOR_RED;
				} else {
					//light up low red for unused slots
					color = LS_COLOR_RED - 0x08;
				}
			}
			uint8_t resolvedIndex = ((j + (ls_page_index * LS_MAX_STEPS_PER_ROW)) % LS_MAX_STEPS_PER_ROW) % MAX_STEPS_ROW;

			if (!useRapidUpdate) {
				ls_updateCell(resolvedIndex, i , color);
			} else {
				ls_grid[resolvedIndex][i] = color;
			}
		}
	}
	
	// arrows buttons
	
	if (useRapidUpdate) {
		//ls_rapidUpdate(ls_grid);
	}
}


// --- UPDATES ---

void updateDisplay(void) {
	switch (current_mode) {
		case kMode_Edit:
			break;
		case kMode_Instr:
			break;
		default:
			break;
	}
	
	ls_updateGrid(false);
}

// --- PATTERN ---

void clearPattern(uint8_t patternIndex) {
	if (patternIndex < N_B_COLS * N_B_ROWS) {
		bzero(&patterns[patternIndex], MAX_STEPS_ROW);
//		patterns[patternIndex] = {0};
	}
}

void clearAllPatterns(void) {
	for (int i = 0; i < N_TRIGGERS; i++) {
		clearPattern(i);
	}
}

// --- OUTPUTS ---

void endTriggerOutput(size_t outputIndex) {
//	if (outputIndex < N_B_COLS * N_B_ROWS) {
//		digitalWrite(t_outputs[outputIndex], LOW);
//		MIDI.sendNoteOff(b_midi_mapping[outputIndex] + midi_mapping_offset, 0, midi_out_channel);
//	}
}

void triggerOutput(size_t outputIndex, uint8_t value) {
	if (outputIndex < N_TRIGGERS) {
#if HOLD_NOTES
		// Analog out
		// Update value no matter if it changed or not
		digitalWrite(t_outputs[outputIndex], value > 0 ? HIGH : LOW);
		// MIDI
		
		// Send a MIDI event only if the state has changed since
		if (state_indexes[outputIndex] != last_state_indexes[outputIndex]) {
			// We need to see if which event to send
			if (state_indexes[outputIndex] && !last_state_indexes[outputIndex]) {
				//noteOn (0 to 1)

			} else if (!state_indexes[outputIndex] && last_state_indexes[outputIndex]) {
				//noteOff (1 to 0)
			}
		}
#else
		if (!muted_triggers[outputIndex]) {
			// TODO: what if we need dotted notes for each step ?
//			digitalWrite(t_outputs[outputIndex], value > 0 ? HIGH : LOW);
//			MIDI.sendNoteOn(b_midi_mapping[outputIndex] + midi_mapping_offset, b_value_mapping[outputIndex], midi_out_channel);
		}
#endif
		
	}
}

// --- SEQ ---

void stopSequencer(void) {
	// Reset all step indexes to 0
	memset(current_step_indexes, 0, sizeof(current_step_indexes));
	current_seq_state = kSequencerState_Stopped;
	updateDisplay();
}

void playSequencer(void) {
	current_seq_state = kSequencerState_Playing;
	updateDisplay();
}

void pauseSequencer(void) {
	current_seq_state = kSequencerState_Paused;
	updateDisplay();
}

// --- Interrupts ---

void clockInterruptCallback() {
	/*
	* When there is no clock in trigger no sequenced output will be triggered !
	*/

	clock_cpt++;

	if (clock_divider > 0) {
		// Block further instructions
		if (clock_cpt % clock_divider != 0) {
			return;
		}
	}
	
	const Direction dir = current_seq_dir;
//	const Direction dir = digitalRead(DIR_PIN) ? kDirection_Backward : kDirection_Forward;
	if (clock_cpt > MAX_STEPS) {
		//TODO: determine highest last step or use defined current max steps (ARTURIA way)
		
	}

	incrCurrentStepIndexes(dir == kDirection_Forward ? 1 : -1);

	// reset all outputs to 0
	//TODO: might find a better way with millis
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		endTriggerOutput(i);
	}

	// trigger every ON outputs selected by the current step
	for (size_t i = 0; i < N_TRIGGERS; i++) {
		triggerOutput(i, patterns[i][current_step_indexes[i]]);
	}
	
	updateDisplay();
}

void resetInterruptCallback() {
	clock_cpt = 0;
	stopSequencer();
	playSequencer();
}

// --- MAIN ---

void setup() {

	// Setup interrupts
	//attachInterrupt(digitalPinToInterrupt(CLOCK_IN_PIN), clockInterruptCallback, RISING);
	//attachInterrupt(digitalPinToInterrupt(RESET_PIN), resetInterruptCallback, RISING);

	// Setup MIDI
}

void loop() {
		
//	updateLeds(); // Update LEDs
//	updateDisplay(); // Update Display
	
	//--- UX LOGIC ---

	switch (current_mode) {
		case kMode_Edit:
			for (size_t i = 0; i < N_TRIGGERS; i++) {
				// assign the pressed buttons to the current pattern
				if (state_indexes[i] > 0) {
					patterns[current_pattern_index][i] = state_indexes[i];
				}
			}
			
			break;
		case kMode_Instr:
			for (size_t i = 0; i < N_TRIGGERS; i++) {
				// turn on matching led
				if (state_indexes[i] > 0) {
//					led[i] = CRGB::Blue;
				}
			}
			
			break;
		default:
			break;
	}

	//--- OUTPUT PART ---

	switch (current_mode) {
		case kMode_Instr:
			// ASSIGN triggers by buttons press
			for (size_t i = 0; i < N_TRIGGERS; i++) {
				triggerOutput(i, state_indexes[i]);
			}
			
			break;
		default:
			break;
	}
}

static MIDIPacketList * packetize_midi_packet();

static void midi_send(const MIDIPacket *pkt, uint8_t channel) {
//	if (gOutPort != NULL && gDest != NULL) {
//
//		MIDIPacketList packetList;
//		MIDIPacketListInit(&packetList);
//
//		// Create a MIDIPacket within the packetList
//		MIDIPacket *packet = MIDIPacketListAdd(&packetList, sizeof(packetList), packetList.data, 0, 3); // 3 is the maximum number of bytes for your MIDI message
//
//		// Populate the MIDI message data in the packet
//		packet->data[0] = 0x90; // MIDI note-on message (example)
//		packet->data[1] = 60;   // Note number
//		packet->data[2] = 100;  // Velocity
//
//		// Send the packet list using MIDISend
//		MIDISend(outputEndpoint, outputEndpoint, &packetList);
//	}
}

static void midi_read_callback(const MIDIPacketList *evtList, void *refCon, void *connRefCon)
{
	if (gOutPort != NULL && gDest != NULL) {
		MIDIPacket *packet = (MIDIPacket *)evtList->packet;
		
		for (size_t j = 0; j < evtList->numPackets; ++j) {
			// go through each pkt bytes
//			for (size_t i = 0; i < packet->length; ++i) {
//
//				// rechannelize status bytes
//				if (packet->data[i] >= kSLMIDIMessageType_NoteOff && packet->data[i] < kSLMIDIMessageType_System) {
//					//packet->data[i] = (packet->data[i] & kSLMIDIMessageType_System) | midi_in_channel;
//				}
//			}
			
			//process packet here
			
			if (packet->length >= 3) {
				if (ls_btnMapValue(packet) == LS_BT_UP_ARROW) {
					
				} else if (ls_btnMapValue(packet) == LS_BT_DOWN_ARROW) {
					
				} else if (ls_btnMapValue(packet) == LS_BT_LEFT_ARROW && ls_btnIsDown(packet)) {
					if (shift_btn_hold) {
						ls_setPageIndex(0);
					} else {
						if (ls_page_index - 1 > 0) {
							ls_setPageIndex(ls_page_index--);
						}
					}
				} else if (ls_btnMapValue(packet) == LS_BT_RIGHT_ARROW && ls_btnIsDown(packet)) {
					if (shift_btn_hold) {
						ls_setPageIndex(0);
					} else {
						if (ls_page_index + 1 < 256) {
							ls_setPageIndex(ls_page_index++);
						}
					}
				} else if (ls_btnMapValue(packet) == LS_BT_MIXER) {
					shift_btn_hold = ls_btnIsDown(packet);
				} else {
					SLMIDIMessageType   type = packet->data[0] & 0xF0;
					uint8_t             incommingChannel = packet->data[0] & 0x0F;
					
					switch(type) {
					  case kSLMIDIMessageType_NoteOn:
						//handleNoteOn(incommingChannel, packet->data[1] & 0xEF, packet->data[2] & 0xEF);
						break;
					  case kSLMIDIMessageType_NoteOff:
						//handleNoteOff(incommingChannel, packet->data[1] & 0xEF, packet->data[2] & 0xEF);
						break;
					  case kSLMIDIMessageType_PitchWheel:
						//handlePitchBendChange(incommingChannel, (packet->data[1] << 8) | packet->data[2]);
						break;
					  case kSLMIDIMessageType_ControlChange:
						//handleControlChange(incommingChannel, packet->data[1] & 0xEF, packet->data[2] & 0xEF);
						break;
					  default:
						break;
					}
				}
#if DEBUG
				printf("-----------------\n");
				printf("SHIFT: %d\n", shift_btn_hold);
				printf("PAGE IDX: %d\n", ls_page_index);
				printf("len: %d \t%02X %02X %02X\n",
					   packet->length,
					   packet->data[0],
					   packet->data[1],
					   packet->data[2]);
#endif
			}
		
			//packet->data[2] = LS_COLOR_YELLOW - 0x08;
			
			packet = MIDIPacketNext(packet);
		}
		
		
		
		//loopback pkt
		MIDISend(gOutPort, gDest, evtList);
	}
}

int main(int argc, const char * argv[]) {
	setup();
	
	// create client and ports
	MIDIClientRef client = NULL;
	MIDIClientCreate(CFSTR("MIDI Echo"), NULL, NULL, &client);

	MIDIPortRef inPort = NULL;
	MIDIInputPortCreate(client, CFSTR("Input port"), midi_read_callback, NULL, &inPort);
	MIDIOutputPortCreate(client, CFSTR("Output port"), &gOutPort);

	// enumerate devices (not really related to purpose of the echo program
	// but shows how to get information about devices)
	int i, n;
	CFStringRef pname, pmanuf, pmodel;
	char name[64], manuf[64], model[64];

	n = (int)MIDIGetNumberOfDevices();
	for (i = 0; i < n; ++i) {
		MIDIDeviceRef dev = MIDIGetDevice(i);

		MIDIObjectGetStringProperty(dev, kMIDIPropertyName, &pname);
		MIDIObjectGetStringProperty(dev, kMIDIPropertyManufacturer, &pmanuf);
		MIDIObjectGetStringProperty(dev, kMIDIPropertyModel, &pmodel);

		CFStringGetCString(pname, name, sizeof(name), 0);
		CFStringGetCString(pmanuf, manuf, sizeof(manuf), 0);
		CFStringGetCString(pmodel, model, sizeof(model), 0);
		CFRelease(pname);
		CFRelease(pmanuf);
		CFRelease(pmodel);

		printf("name=%s, manuf=%s, model=%s\n", name, manuf, model);
	}

	// open connections from all sources
	n = (int)MIDIGetNumberOfSources();
	printf("%d sources\n", n);
	for (i = 0; i < n; ++i) {
		MIDIEndpointRef src = MIDIGetSource(i);
		MIDIPortConnectSource(inPort, src, NULL);
	}

	// find the first destination
	n = (int)MIDIGetNumberOfDestinations();
	if (n > 0)
		gDest = MIDIGetDestination(0);

	if (gDest != NULL) {
		MIDIObjectGetStringProperty(gDest, kMIDIPropertyName, &pname);
		CFStringGetCString(pname, name, sizeof(name), 0);
		CFRelease(pname);
		printf("Echoing to channel %d of %s\n", midi_out_channel, name);
	} else {
		printf("No MIDI destinations present\n");
	}

	CFRunLoopRun();
	// run until aborted with control-C

//	while(true) {
//		loop();
//	}
	
	return 0;
}
